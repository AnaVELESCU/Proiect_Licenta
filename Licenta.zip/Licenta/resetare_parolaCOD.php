<?php

$con=mysqli_connect("localhost","root","", "licenta") or die ("Nu se poate conecta la serverul MySQL");

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'C:\xampp\htdocs\Licenta\PHPMailer/src/Exception.php';
require 'C:\xampp\htdocs\Licenta\PHPMailer/src/PHPMailer.php';
require 'C:\xampp\htdocs\Licenta\PHPMailer/src/SMTP.php';

$message= "";
if(isset($_POST['submit'])) {

if(isset($_POST["email"])) {

    $emailTo = $_POST["email"];

    $code = uniqid(true);
    $query = mysqli_query( $con, "INSERT INTO resetare_parola(code,Email) VALUES('$code','$emailTo')");
    if(!$query) {
        exit("Error");
    }
$mail = new PHPMailer(true);
$mail->Mailer = "smtp";

    try {
 
        $mail->isSMTP();                                            
        $mail->Host       = "smtp.gmail.com";                     
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = "velescuana130@gmail.com";                    
        $mail->Password   = "tqxadzoolmfimtsf";                              
        $mail->SMTPSecure = "ssl";            
        $mail->Port       = 465;                                    

        $mail->setFrom("velescuana130@gmail.com","Ana Velescu");
        $mail->addAddress($emailTo);    
        $mail->addReplyTo('no-reply@gmail.com', 'No reply');

    
        $url= "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER["PHP_SELF"]) . "/newPassword.php?code=$code";
        $mail->isHTML(true);                               
        $mail->Subject = 'Link resetare parola';
        $mail->Body    = "<h4>Ai soloicitat o resetare de parola<h4>
                            Click <a href='$url'>aici </a>pentru a reseta parola ";
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        $message= 'Reseteaza parola accesand link-ul trimis pe email';

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
  

}

}

?>

