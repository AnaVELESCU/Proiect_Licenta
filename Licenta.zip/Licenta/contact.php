

<!DOCTYPE html>
<?php include('php/startSesiune.php') ?>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title></title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/stylesMeniu.css" rel="stylesheet" />
        <link href="css/style_contact.css" rel="stylesheet" />
    </head>
    <body>
        <!-- Responsive navbar-->
        <?php include('meniuN.php'); ?>
        <?php include('php/contactPHP.php') ?>
     
        <!-- Page content-->
        <div class="container">

          <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <p>Pentru orice problema intampinata pe site va rog frumos sa ma contacta-ti printr-un mail in care sa descrieti problema aparuta.Va multumesc!</p>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"><div class="gg-pin"></div></i>
                <h4>Locatie:</h4>
                <p>Strada Episcopiei, Caransebeș 325400</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"><div class="gg-mail"></div> </i>
                <h4>Email:</h4>
                <p>velescuana130@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi gg-phone"><div class="gg-smartphone"></div></i>
                <h4>Telefon:</h4>
                <p>073032369</p>
              </div>

              
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d990.2496182765159!2d22.21712488459618!3d45.41238685747606!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x474e31c2a1df1575%3A0x73fc927250542a2e!2sCaransebe%C8%99%20325400!5e0!3m2!1sro!2sro!4v1683203470743!5m2!1sro!2sro" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>

            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form  role="form" class="php-email-form"   method="POST">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Nume</label>
                  <input type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Email</label>
                  <input type="email" class="form-control" name="email" id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subiect</label>
                <input type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Mesaj</label>
                <textarea class="form-control" name="message" rows="10" required></textarea>
              </div>
              
              
              
              <div class="text-center"><button type="submit" class="btn btn-primary" name="submit_contact">Trimite</button></div>
              <div class="row text-center"><span style="color:green" ><?php echo $mailTrimis; ?></span></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->


        
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>

        <footer class="py-5 bg-dark">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p></div>
        </footer>
    </body>
</html>