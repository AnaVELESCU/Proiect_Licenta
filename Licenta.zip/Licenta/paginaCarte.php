<?php include('php/startSesiune.php'); ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <title></title>
      <!-- Favicon-->
      <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
      <!-- Core theme CSS (includes Bootstrap)-->
      <link href="css/stylesMeniu.css" rel="stylesheet" />
   </head>
   <body>
      <?php include('meniuN.php'); ?>
      <?php
      $image_id = $_GET['ID'];
      $result = mysqli_query($con, "SELECT a.email, a.Nume_carte, a.Autor, a.Nr_bucati, a.Categorie, a.Stare, a.Anul_lansarii, a.Descriere , b.img1, b.img2, b.img3, b.ID_carte, b.size, b.type FROM doneaza a JOIN poze b ON a.ID = b.ID_carte and $image_id=a.ID");
      $row = mysqli_fetch_assoc($result);
      
       ?>
      <section class="py-5">
         <div class="container px-4 px-lg-5 my-5">
            <div class="row gx-4 gx-lg-5 align-items-center">
               <div class="col-md-6">
               <div id="imageCarousel" class="carousel slide" data-bs-ride="carousel">
   <div class="carousel-inner">
      <?php if (!empty($row['img1'])): ?>
      <div class="carousel-item active col-md-6">
         <img src="<?php echo $row['img1']; ?>" class="d-block card-img-top mb-5 mb-md-0" alt="Image 1" />
      </div>
      <?php endif; ?>
      <?php if (!empty($row['img2'])): ?>
      <div class="carousel-item col-md-6">
         <img src="<?php echo $row['img2']; ?>" class="d-block card-img-top mb-5 mb-md-0" alt="Image 2" />
      </div>
      <?php endif; ?>
      <?php if (!empty($row['img3'])): ?>
      <div class="carousel-item col-md-6">
         <img src="<?php echo $row['img3']; ?>" class="d-block card-img-top mb-5 mb-md-0" alt="Image 3" />
      </div>
      <?php endif; ?>
   </div>
   <button class="carousel-control-prev" type="button" data-bs-target="#imageCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
   </button>
   <button class="carousel-control-next" type="button" data-bs-target="#imageCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
   </button>
</div>
               </div>
               <div class="col-md-6">
                  <h1 class="display-5 fw-bolder"><?php echo $row['Nume_carte']; ?> </h1>
                  <p class="lead">
                     <p>Autor: <?php echo $row['Autor']; ?></p>
                     <p>Nr_bucati: <?php echo $row['Nr_bucati']; ?></p>
                     <p>Categorie: <?php echo $row['Categorie']; ?></p>
                     <p>Stare: <?php echo $row['Stare']; ?></p>
                     <p>Anul lansarii: <?php echo $row['Anul_lansarii']; ?></p>
                     <p>Descriere: <?php echo $row['Descriere']; ?></p>
                     <p>Daca doriti cartea, va rog sa ma contactati pe adresa de mail: <?php echo $row['email']; ?></p>
                     <?php
                     $message="";
                     if (isset($_SESSION['email'])) {
                        $user_email = $_SESSION['email'];
                        if ($user_email == $row['email']) {
                           echo '<div class="text-left"><form method="POST" ><button type="submit" class="btn btn-primary" name="submit_ca">Sterge carte</button></form></div>';
                    
                           if (isset($_POST['submit_ca'])) {
                              $result = mysqli_query($con, "DELETE FROM doneaza WHERE email = '$user_email' AND ID='$image_id'");
                              $result1 = mysqli_query($con, "DELETE FROM poze WHERE email = '$user_email' AND ID_carte='$image_id'");
                              echo '<script>window.location.href = "cartiDisponibile.php";</script>';
                              exit;
                             
                           }
                        }
                     }
                     ?>
                  </p>
               </div>
            </div>
         </div>
      </section>
      <!-- Bootstrap core JS -->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <!-- Core theme JS-->
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
      <script src="js/scripts.js"></script>
      <footer class="py-5 bg-dark">
         <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p>
         </div>
      </footer>
   </body>
</html>
