<?php
$userNeinregistrat=$parolaGresita="";
session_start();
$conn=mysqli_connect("localhost","root","", "licenta") or die ("Nu se poate conecta la serverul MySQL");

if(!empty($_SESSION["email"])){
    header("Location: index.php");
  }
if(isset($_POST["submit"])){
  $Email = $_POST["email"];
  $Parola = $_POST["pass"];
  $result = mysqli_query($conn, "SELECT * FROM user WHERE Email = '$Email'");
  $row = mysqli_fetch_assoc($result);
  if(mysqli_num_rows($result) > 0){
   
    if($Parola == $row["Parola"]){
      $_SESSION["email"] = $Email;
      
    
      header("Location:indexAcasa.php");
    
      
    }
    else{
      $parolaGresita= "Parola gresita";
    }
  }
  else{
    $userNeinregistrat="User-ul nu este inregistrat";

  }
  
}
?>
