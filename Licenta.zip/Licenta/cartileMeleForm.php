<?php include('php/startSesiune.php'); ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <title></title>
      <!-- Favicon-->
      <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
      <!-- Core theme CSS (includes Bootstrap)-->
      <link href="css/style_contact.css" rel="stylesheet" />
      <link href="css/stylesMeniu.css" rel="stylesheet" />
   </head>
   <body>
      <!-- Responsive navbar-->
      <?php include('meniuN.php'); ?>
      <!-- Page content-->
      <?php include('php/cartiCititePHP.php') ?>
      <section id="contact" class="contact">
         <div class="container">
            <div class="row justify-content-center" data-aos="fade-in">
               <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
                  <form  role="form" class="php-email-form" method="POST" enctype="multipart/form-data" >
                     <div class="row">
                        <div class="form-group col-md-6">
                           <label for="name">Nume Carte</label>
                           <input type="text" name="nume_carte" class="form-control" id="nume_carte" required>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="name">Autor</label>
                           <input type="autor" class="form-control" name="autor" id="autor" required>
                        </div>
                     </div>
                 
                     <div class="row">
                        <div class="form-group col-md-6">
                           <label for="name">Categorie</label>
                           <select class="form-control" name="categorie">
                              <option>Carte citita</option>
                              <option>Carte pe care vreau sa o citesc</option>
                           </select>
                        </div>
                       
                     </div>
                     <div class="form-group">
                        <label for="name">O scurta descriere</label>
                        <textarea class="form-control" name="descriere" rows="10" required></textarea>
                     </div>
                     <div class="row">
                     <div class="col-md-4"><label for="photos">Alege maxim 3 fotografii:</label>
                      <input type="file" text="alege"  name="photos" id="photos" multiple ></div>
                      <div class="row text-center"><span style="color:red" ><?php echo $messageUpload ,$errorDataBaseUpload ,$errorFolderUpload; ?></span></div>
                    </div>

                        <div class="row justify-content-center"><div class="col-md-2"><button type="submit" class="btn btn-primary btn-lg" name="submit">Trimite</button></div><span style="color:green" class="text-center"><?php echo $sendSucces; ?></span></div></div>
                    
                       
                     
                  </form>                    
               </div>
            </div>
         </div>
      </section>
      <!-- Bootstrap core JS-->
      <
      <footer class="py-5 bg-dark">
         <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p>
         </div>
      </footer>
   </body>
</html>