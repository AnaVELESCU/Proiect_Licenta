<?php include('php/startSesiune.php'); ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <title></title>
      <!-- Favicon-->
      <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
      <!-- Core theme CSS (includes Bootstrap)-->
      <link href="css/stylesMeniu.css" rel="stylesheet" />
      <link href="css/donatii.css" rel="stylesheet"/>
      
     
   </head>
   <body>
      <!-- Responsive navbar-->
      <?php include('meniuN.php'); ?>
      
         <form method="POST">
         <div class="row justify-content-end mt-3">
            <div class="col-md-3">
               <div class="input-group ">
                  <input name="input_search" class="form-control " type="text" placeholder="Caută cartea după nume..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                  <button class="btn btn-primary" id="btnNavbarSearch" name="search" type="submit"><i class=" gg-search fas fa-search"></i></button>
               </div>
            </div>
         </div>
         
         </form>
         <section class="py-1">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php include('php/search.php') ?>
                
                </div>
            </div>
        </section>
        <div class="row text-center"><span style="color:black" ><?php echo $errr; ?></span></div>
      <section class="py-5">
            <div class="container px-4 px-lg-5 mt-5">
                <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php include('php/cartiDisponibilePHP.php') ?>
                    
                </div>
            </div>
        </section>
      <a href="#top" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
      <!-- Bootstrap core JS-->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <!-- Core theme JS-->
      <script src="js/scripts.js"></script>
      <footer class="py-5 bg-dark">
         <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p>
         </div>
      </footer>
   </body>
</html>