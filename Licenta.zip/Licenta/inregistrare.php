<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link href="css/stylesMeniu.css" rel="stylesheet" />
    <link rel="stylesheet" href="css/inregistrare.css">
</head>
<body class="body">
<?php include('php/connect.php') ?>
    <div class="main">
        <section class="signup">
            <!-- <img src="images/signup-bg.jpg" alt=""> -->
            <div class="container">
                <div class="signup-content">
                    <form  method="POST" id="signup-form" class="signup-form">
                        <h2 class="form-title">Înregistrează-te</h2>
                        <div class="form-group">
                            <input type="text" class="form-input" name="name" id="name" placeholder="Nume"/>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-input" name="email" id="email" placeholder="Email"/>
                        </div>
                        <div class="form-group">
                            <input type="number" class="form-input" name="phone-number" id="phone-number" placeholder="Numar telefon"/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input" name="password" id="password" aria-hidden="true" placeholder="Parola"/>
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input" name="re_password" id="re_password" aria-hidden="true" placeholder="Confirmă parolă"/>
                        </div>
                        <div class="form-group">
                            <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                            <label for="agree-term" class="label-agree-term"><span><span></span></span>Accept termeni si condițiile  <a href="#" class="term-service">Termeni și condiții</a></label>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Înregistrare"/> 
                            
                       
                            </div>
                            <div class="row text-center justfy-content-center"><span style="color:red" ><?php echo $message, $message1;  ?></span></div>
                            <p class="loginhere">
                        Ai deja cont ? <a href="index.php" class="loginhere-link">Conectează-te aici</a>
                    </p>
                    </form>
                   
                </div>
            </div>
        </section>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/pws.js"></script>
</body>
</html>