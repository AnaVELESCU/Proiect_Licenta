<?php include('php/startSesiune.php'); ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <title></title>
      <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
      <link href="css/stylesMeniu.css" rel="stylesheet" />
      <link href="css/forgotpassword.css" rel="stylesheet" />
      <link href="css/cartiDisponibile.css" rel="stylesheet" />
   </head>
   <body>
      <!-- Responsive navbar-->
      <?php include('meniuN.php'); ?>
   <div class="citat">
         
      <div class="row justify-content-center ">
      
       
         <div class="col-lg text-center py-5 font-monospace " ><a style="text-decoration:none;" href="cartileMeleForm.php"><h5>Carți citite</h5></a>
         <div class=" text-center "><form method="POST" action="php/generarePDF.php"><button type="submit" class="btn btn-primary "name="generare_pdf" >Generare pdf</button></form></div> </div>

         <!-- rand carti citite-->
         <section class="py-1">
            <div class="container px-4 px-lg-5 mt-2">
               <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                  <?php 
                     if (isset($_SESSION['email']))
                     {
                        $user_email = $_SESSION['email'];
                     }
                     $result = mysqli_query($con, "SELECT img, id FROM carticitite where email='$user_email'");
                 
                     while ($row = mysqli_fetch_assoc($result)) {
                           
                        $IdCarte=$row['id'];
                        $img1=$row['img'];
                     
                        echo '<div class="col mb-2">';
                        echo '<div class="card h-100 min-vh-35">';
                        echo '<a href="AfisareCarteUser.php?ID='.$IdCarte.'&categorie=2"><img class="card-img-overlay" src='.$img1.' alt="..." /></a>';
                     
                        echo '</div>';
                        echo '</div>';
                     }
                     
                     ?>
               </div>
            </div>
         </section>
          </div>
  
      <div class="row justify-content-center ">
         <div class="col-lg text-center py-5 font-monospace " ><a style="text-decoration:none;" href="cartileMeleForm.php"><h5>Carți pe care doresc să le citesc</h5></a> </div>
         <section class="py-1">
            <div class="container px-4 px-lg-5 mt-2">
               <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                  <?php 
                     if (isset($_SESSION['email']))
                     {
                        $user_email = $_SESSION['email'];
                     }
                    
                     $result = mysqli_query($con, "SELECT img, id FROM cartipecarevreausalecitesc where email='$user_email'");
                     
                    
                     while ($row = mysqli_fetch_assoc($result)) {
                           
                        $IdCarte=$row['id'];
                        $img1=$row['img'];
                     
                        echo '<div class="col mb-2">';
                        echo '<div class="card h-100 min-vh-35">';
                        echo '<a href="AfisareCarteUser.php?ID='.$IdCarte.'&categorie=3"><img class="card-img-overlay" src='.$img1.' alt="..." /></a>';
                     
                        echo '</div>';
                        echo '</div>';
                     }
                     
                     ?>
               </div>
            </div>
         </section>
      </div>


      <div class="row justify-content-center ">
         <div class="col-lg text-center py-5 font-monospace " ><a style="text-decoration:none;" href="#"><h5>Carțile mele din aplicație</h5></a> </div>
         <section class="py-1">
            <div class="container px-4 px-lg-5 mt-2">
               <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                  <?php 
                     if (isset($_SESSION['email']))
                     {
                        $user_email = $_SESSION['email'];
                     }
                   
                     $result = mysqli_query($con, "SELECT a.email, a.Nume_carte, a.Autor, a.Nr_bucati, a.Categorie, a.Stare, a.Anul_lansarii, a.Descriere , b.img1, b.img2, b.img3, b.ID_carte, b.size, b.type FROM doneaza a JOIN poze b ON a.ID = b.ID_carte where a.email='$user_email'");

                     
                     $html = '';
                     echo '';

                     while ($row = mysqli_fetch_assoc($result)) {
                           
                        $IdCarte=$row['ID_carte'];
                        $img1=$row['img1'];

                        echo '<div class="col mb-5">';
                        echo '<div class="card h-100 min-vh-35">';
                        echo '<a href="paginaCarte.php?ID='.$IdCarte.'"><img class="card-img-overlay" src='.$img1.' alt="..." /></a>';
                     
                        echo '</div>';
                        echo '</div>';
                     }

                     ?>
               </div>
            </div>
          
         </section>
      </div>
                  </div>
      <!-- Bootstrap core JS-->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <!-- Core theme JS-->
      <script src="js/scripts.js"></script>
      <footer class="py-5 bg-dark">
         <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p>
         </div>
      </footer>
   </body>
</html>