<?php 

$result = mysqli_query($con, "SELECT a.email, a.Nume_carte, a.Autor, a.Nr_bucati, a.Categorie, a.Stare, a.Anul_lansarii, a.Descriere , b.img1, b.img2, b.img3, b.ID_carte, b.size, b.type 
FROM doneaza a JOIN poze b ON a.ID = b.ID_carte");


while ($row = mysqli_fetch_assoc($result)) {
      
    $IdCarte=$row['ID_carte'];
    
    $img1=$row['img1'];

   echo '<div class="col mb-5">';
   echo '<div class="card h-100 min-vh-35">';
   echo '<a href="paginaCarte.php?ID='.$IdCarte.'"><img class="card-img-overlay" src='.$img1.' alt="..." /></a>';
  
   echo '</div>';
   echo '</div>';
}



?>

