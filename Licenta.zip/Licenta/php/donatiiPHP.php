<?php
$sendSucces = "";
$errorFolderUpload=$errorDataBaseUpload=$messageUpload="";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
// adăugare cu parametri
if (isset($_POST['submit']))
{
    $nume_carte = $_POST['nume_carte'];
    $autor = $_POST['autor'];
    $nr_bucati = $_POST['nr_bucati'];
    $categorie = $_POST['categorie'];
    $stare = $_POST['stare'];
    $anul_lansarii = $_POST['anul_lansarii'];
    $descriere = $_POST['descriere'];
    if (isset($_SESSION['email']))
    {
        $user_email = $_SESSION['email'];
    }

    $query1 = "insert into doneaza (email,Nume_carte,Autor,Nr_bucati,Categorie,Stare,Anul_lansarii,Descriere) values('$user_email','$nume_carte','$autor','$nr_bucati','$categorie','$stare','$anul_lansarii','$descriere')";
    if (!$con->query($query1) === true)
    {
        $sendSucces = "Error inserting data: " . $con->error;
    }
    
    if (isset($_FILES['photos']))
    {
		$files = $_FILES['photos'];
        if (count($files['name']) ==0){
        $messageUpload= "Selecteaza cel putin o poza";
        }
             else if (count($files['name']) > 3)
        {
           $messageUpload= "Prea multe poze selectate, aveti voie doar 3 poze.";
        }
        else
        {
            // Folder-ul unde se salvează pozele
            $target_dir = "uploadIMG/";
            // Inserează numele pozelor în baza de date
            $name1 = "";
            $name2 = "";
            $name3 = "";
            $sql = "SELECT MAX(ID) as max_id FROM doneaza";
            $result = $con->query($sql);
            
            if ($result->num_rows > 0) {
                // Afiseaza rezultatele
                $row = $result->fetch_assoc();
                $last_id = $row["max_id"];
            }


            for ($i = 0;$i < count($files['name']);$i++)
            {
                // Get file name, size, and type
                $file_name = $files['name'][$i];
                $file_size = $files['size'][$i];
                $file_type = $files['type'][$i];
                // Get file name and path
                $target_file = $target_dir . $file_name;

                $file_name = $files['name'][$i];
                $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

                // Generate new file name with timestamp and random number
                
                // Move uploaded file to destination folder with new name
                if (!move_uploaded_file($files['tmp_name'][$i], $target_file))
                {
                    $errorFolderUpload="Trebuie sa selectati cel putin o poza " . $file_name . ".<br>";
                    
                }
              
                if ($i == 0)
                {
                    $name1 = $target_file;
                }
                elseif ($i == 1)
                {
                    $name2 = $target_file;
                }
                elseif ($i == 2)
                {
                    $name3 = $target_file;
                }
            }
                // Insert file into the database
                $sql = "INSERT INTO poze (email, img1, img2, img3, ID_carte, size, type) VALUES ('$user_email', '$name1', '$name2', '$name3','$last_id', '$file_size', '$file_type')";
                if (!mysqli_query($con, $sql) )
                {
                    $errorDataBaseUpload= "Error: " . $sql . "<br>" . mysqli_error($con);
                }
              
            
        }
   
       
    }
	if(empty($sendSucces)&& empty($errorFolderUpload) && empty($errorDataBaseUpload) && empty($messageUpload)) {
		$sendSucces= "Datele au fost salvate cu succes";

        $query2=mysqli_query($con,"SELECT * from cartipecarevreausalecitesc where notificare='1'");
       
        foreach($query2 as $query)
        {
            if( $query ['Nume_carte']==$nume_carte && $query ['Autor']==$autor ) {

                require 'C:\xampp\htdocs\Licenta\PHPMailer/src/Exception.php';
                require 'C:\xampp\htdocs\Licenta\PHPMailer/src/PHPMailer.php';
                require 'C:\xampp\htdocs\Licenta\PHPMailer/src/SMTP.php';


                    $emailTo = $query ['email'] ;

                
                $mail = new PHPMailer(true);
                $mail->Mailer = "smtp";

                    try {

                        $mail->isSMTP();                                          
                        $mail->Host       = "smtp.gmail.com";                     
                        $mail->SMTPAuth   = true;                                   
                        $mail->Username   = "velescuana130@gmail.com";                     
                        $mail->Password   = "tqxadzoolmfimtsf";                               
                        $mail->SMTPSecure = "ssl";            
                        $mail->Port       = 465;                                    
                    
                        $mail->setFrom("velescuana130@gmail.com","Ana Velescu");
                        $mail->addAddress($emailTo);    
                        $mail->addReplyTo('no-reply@gmail.com', 'No reply');
                     
                        $mail->isHTML(true);                             
                        $mail->Subject = 'Cartea este diponibila in aplicatie';
                        $mail->Body    = "<h4>Cartea căutată cu titlul: <small>$nume_carte</small> este disponibilă în aplicație, o găsiți în pagina Carți disponibile. </h4>";
                  
                        $mail->send();
               
                    } catch (Exception $e) {
                        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                    }
                    

                }

            }
        }

	}





?>
