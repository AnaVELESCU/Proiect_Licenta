<?php
$con=mysqli_connect("localhost","root","", "licenta") or die ("Nu se poate conecta la serverul MySQL");

$message= "";
$message1= "";

if (isset($_POST['submit'])) {

 $Nume=$_POST['name'];
 $Email=$_POST['email'];
 $Telefon=$_POST['phone-number'];
 $Parola=$_POST['password'];
 $ConfirmaParola=$_POST['re_password'];


//se verifica daca user-ul care se doreste sa se insereze nu exista deja in baza de date
//daca nu exista, se insereaza; daca exista, se afiseaza un mesaj de eroare
$query=mysqli_query($con, "select count(*) from user where email='$Email'");
$row=mysqli_fetch_row($query);
$nr=$row[0];
if ($nr==0){
    if($Parola==$ConfirmaParola) {
// adăugare cu parametri
$query1=mysqli_query($con,"insert into user(Nume,Email,Telefon,Parola) values('$Nume','$Email','$Telefon','$Parola')") or die ("Inserarea nu a putut avea loc!". mysqli_error($con));

header("Location:\Licenta\index.php");
    exit();
    }
    else{
       
        $message = "Parolele introduse nu coincid";
    }

}
else{
  $message1 = "Userul există deja în baza de date";
}

}

?> 