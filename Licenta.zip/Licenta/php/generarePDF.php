<?php
require_once('C:\xampp\htdocs\Licenta\dompdf\vendor\autoload.php');
require_once('startSesiune.php'); 

use Dompdf\Dompdf;

if (isset($_POST['generare_pdf'])) {
    
    $dompdf = new Dompdf();
    if (isset($_SESSION['email']))
    {
       $user_email = $_SESSION['email'];
    }
    $query = "SELECT * FROM carticitite where email='$user_email'";

    $result = mysqli_query($con, $query);
    $html = '<html><body><h1>Lista carti citite: </h1>';

    
    while ($row = mysqli_fetch_assoc($result)) {
        $title = $row['Nume_carte'];
        $author = $row['Autor'];
        $description = $row['Descriere'];
        $html .= "<p>Titlu: $title</p><p>Autor: $author</p><p>Descriere: $description</p><br>";
    }

    $html .= '</body></html>';
    $dompdf->loadHtml($html);

    $dompdf->render();
    $dompdf->stream('generarePDF.pdf', ['Attachment' => true]);

}
?>