<?php 
$errr="";
if (isset($_POST['search'])) {
  
   $searchTerm = $_POST['input_search'];

   $sql = "SELECT a.email, a.Nume_carte, a.Autor, a.Nr_bucati, a.Categorie, a.Stare, a.Anul_lansarii, a.Descriere, b.img1, b.img2, b.img3, b.ID_carte, b.size, b.type 
   FROM doneaza a
   JOIN poze b ON a.ID = b.ID_carte
   WHERE LOWER( a.Nume_carte) LIKE LOWER( '%$searchTerm%') OR LOWER( a.Autor) LIKE LOWER( '%$searchTerm%')" ;

   $result = mysqli_query($con, $sql);

   if (mysqli_num_rows($result) > 0) {
      
       while ($row = mysqli_fetch_assoc($result)) {
      
         $IdCarte=$row['ID_carte'];
         $img1=$row['img1'];
     
        echo '<div class="col mb-5">';
        echo '<div class="card h-100 min-vh-35">';
        echo '<a href="paginaCarte.php?ID='.$IdCarte.'"><img class="card-img-overlay" src='.$img1.' alt="..." /></a>';
       
        echo '</div>';
        echo '</div>';
     }
   } else {

      $errr= ' <div class="row text-center"> <p>Nu am găsit cartea căutată! Adaugă cartea pentru a primi notificare atunci când aceasta este disponibilă<a  href="cartileMele.php"> aici </a> in sectiunea Carți pe care doresc să le citesc</p></div>';
   }

   mysqli_free_result($result);
}?>