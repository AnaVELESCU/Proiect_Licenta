<?php
   session_start();
   $con=mysqli_connect("localhost","root","", "licenta") or die ("Nu se poate conecta la serverul MySQL");
   
   if(!empty($_SESSION["email"])){
     $Email = $_SESSION["email"];
     $result = mysqli_query($con, "SELECT * FROM user WHERE email = '$Email'");
     $row = mysqli_fetch_assoc($result);
   }
   else{
     header("Location: index.php");
   }
   ?>