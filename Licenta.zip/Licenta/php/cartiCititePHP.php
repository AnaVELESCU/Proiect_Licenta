<?php
$sendSucces = "";
$errorFolderUpload=$errorDataBaseUpload=$messageUpload="";
// adăugare cu parametri
if (isset($_POST['submit']))
{
  if (isset($_POST['categorie']))
  {
          $nume_carte = $_POST['nume_carte'];
          $autor = $_POST['autor'];
          $categorie = $_POST['categorie'];
          $descriere = $_POST['descriere'];
         
          if (isset($_SESSION['email']))
          {
              $user_email = $_SESSION['email'];
          }
          $folder='userIMG/';
     
      if (isset($_FILES['photos']))
      {
        $img = $_FILES['photos'];
        $cale=$folder.$img['name'];
        if (!move_uploaded_file($img['tmp_name'], $cale))
        {
            $errorFolderUpload="Eroare la incarcarea imaginii " . $cale . ".<br>";
            
        }
      
      
      if($categorie=='Carte pe care o citesc')
          $query1 = "insert into cartipecarelecitescacum (email,Nume_carte,Autor,Descriere,img) values('$user_email','$nume_carte','$autor','$descriere','$cale')";
      if($categorie=='Carte citita')
          $query1 = "insert into carticitite (email,Nume_carte,Autor,Descriere,img) values('$user_email','$nume_carte','$autor','$descriere','$cale')";
      if($categorie=='Carte pe care vreau sa o citesc')
          $query1 = "insert into cartipecarevreausalecitesc (email,Nume_carte,Autor,Descriere,img) values('$user_email','$nume_carte','$autor','$descriere','$cale')";
          if (!$con->query($query1) === true)
          {
              $sendSucces = "Error inserting data: " . $con->error;
          }
        }
        else{$errorFolderUpload="Eroare la incarcarea imaginii ";}
        
  } 
    
	if(empty($sendSucces)&& empty($errorFolderUpload) && empty($errorDataBaseUpload) && empty($messageUpload)) {
		$sendSucces= "Datele au fost salvate cu succes";

	}
}

?>
