<?php
   $con=mysqli_connect("localhost","root","", "licenta") or die ("Nu se poate conecta la serverul MySQL");

   $message="";
   
   if(!isset($_GET["code"])) {
     exit("Nu pot gasi pagina");
   }
   
   $code = $_GET["code"];
   
   $getEmailQuery = mysqli_query($con, "SELECT Email FROM resetare_parola WHERE code='$code'");
   if(mysqli_num_rows($getEmailQuery) == 0) {
     exit("Link ul pentru a reseta parola a fost deja utilizat");
   }
   
   if(isset($_POST["password"])) {
     $pw=$_POST["password"];
    // $pw=md5($pw);          //parola criptata
   
     $row= mysqli_fetch_array($getEmailQuery);
     $email=$row['Email'];
   
     $query = mysqli_query($con, "UPDATE user SET Parola='$pw' WHERE Email='$email'");
   
     if($query) {
       $query= mysqli_query($con, "DELETE FROM resetare_parola WHERE code='$code' ");
     $message= 'Parola actualizată';
     }
     else {
       exit("ceva nu a mers bine");
     }
   }
   
   
   ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="css/forgotpassword.css">
   </head>
   <body>
      <div class="principal">
         <div class="container d-flex flex-column">
            <div class="row align-items-center justify-content-center
               min-vh-100">
               <div class="col-12 col-md-8 col-lg-4">
                  <div class="card shadow-sm">
                     <div class="card-body">
                        <div class="mb-4">
                           <h5>Resetare parolă</h5>
                           <p class="mb-2">Te rog să introduci noua parolă 
                           </p>
                        </div>
                        <form method="POST">
                           <div class="mb-3">
                              <label for="password" class="form-label">Parolă:</label>
                              <input type="password" id="password" class="form-control" name="password" placeholder="Parola" required="" >
                           </div>
                           <div class="mb-3 d-grid">
                              <button type="submit" name="submit" class="btn btn-primary" value="Save" >
                              Resetează parolă
                              </button>
                           </div>
                           <div class="row text-center"><span style="color:green" ><?php echo $message; ?></span></div>
                           <div class="text-center p-t-12">
                  <span class="txt1">
                  Conectează-te
                  </span>
                  <a class="txt2" href="index.php">
                  aici
                  </a>
               </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>