<?php include('php/startSesiune.php'); ?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <title></title>
      <!-- Favicon-->
      <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
      <!-- Core theme CSS (includes Bootstrap)-->
      <link href="css/stylesMeniu.css" rel="stylesheet" />
      <link href="css/forgotpassword.css" rel="stylesheet" />
      <link href="\Licenta\assets\css\style.css" rel="stylesheet" />
   </head>
   <body>
     
      <!-- Responsive navbar-->
      <?php include('meniuN.php'); ?>
      <!-- Page content-->
      <div class=" citat">
         <div class="row justify-content-center ">
            <div class="col-lg text-center py-5 font-monospace " >
               <i >
                  <h5> "Într-o lume aflată mereu în schimbare, cărțile rămân neschimbate. Ele sunt prietenii tăi veșnici." - Carl Sagan</h5>
               </i >
            </div>
         </div>
         
         <?php
$query = "SELECT sub.*
FROM (
    SELECT a.email, a.Nume_carte, a.Autor, a.Nr_bucati, a.Categorie, a.Stare, a.Anul_lansarii, a.Descriere, b.img1, b.img2, b.img3, b.ID_carte, b.size, b.type,
           ROW_NUMBER() OVER (PARTITION BY a.Categorie ORDER BY a.ID DESC) AS row_num
    FROM doneaza a
    JOIN poze b ON a.ID = b.ID_carte
) AS sub
WHERE sub.row_num <= 5";

$result = mysqli_query($con, $query); 


if ($result) {
   
    $currentCategory = null;
    while ($row = mysqli_fetch_assoc($result)) {
        $category = $row['Categorie'];
        $bookName = $row['Nume_carte'];
        $author = $row['Autor'];
        $bookID = $row['ID_carte'];
        $image1 = $row['img1'];
        $IdCarte=$row['ID_carte'];
   
        if ($category !== $currentCategory) {
            echo '<div class="carusel">';
            echo '<div class="row justify-content-center md-0">';
            echo '<div class="mt-md-2 text-center py-5">';
            echo '<i><h5>Cele mai recente carți din categoria:</h5></i>';
            echo '<h2>'.$category.'</h2>';
            echo '</div>';
            echo '</div>';
            echo '<div class="row justify-content-center book-row">'; // Start a new row for the books

            $currentCategory = $category;
        }

        echo '<div class="col-md-2 book-container">';
        echo '<div class= "box"> <a href="paginaCarte.php?ID='.$IdCarte.'"><img  src="'.$image1.'" alt="Book Cover"></a></div>';
    
  
        echo '</div>';
    }

    echo '</div>'; 
    mysqli_free_result($result);
} else {

    echo 'Error executing the query: '.mysqli_error($con);
}

mysqli_close($con);
?>

      <!-- TOP -->
      <!-- Template Main JS File -->
      <script src="assets/js/main.js"></script>
      <!-- Bootstrap core JS-->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <!-- Core theme JS-->
      <script src="js/scripts.js"></script>
      <footer class="py-5 bg-dark">
         <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p>
         </div>
      </footer>
   </body>
</html>