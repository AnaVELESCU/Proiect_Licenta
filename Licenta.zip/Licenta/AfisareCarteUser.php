<?php include('php/startSesiune.php'); ?>
<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <title></title>

      <link href="css/stylesMeniu.css" rel="stylesheet" />
      <link href="css/forgotpassword.css" rel="stylesheet" />
   </head>
   <body>
      <?php include('meniuN.php'); ?>
      <?php
         $image_id = $_GET['ID'];
         $categorie = $_GET['categorie'];
         if($categorie=='1'){
         $result = mysqli_query($con, "SELECT Nume_carte, Autor, Descriere, img FROM cartipecarelecitescacum where id = '$image_id'");
         $row = mysqli_fetch_assoc($result);
          }
         if($categorie=='2'){
           $result = mysqli_query($con, "SELECT Nume_carte, Autor, Descriere, img FROM carticitite where id = '$image_id'");
           $row = mysqli_fetch_assoc($result); }
           if($categorie=='3')  {
             $result = mysqli_query($con, "SELECT Nume_carte, Autor,  Descriere, img FROM cartipecarevreausalecitesc where id = '$image_id'");
             $row = mysqli_fetch_assoc($result); }
          
            ?>
      <section class="py-5">
         <div class="container px-4 px-lg-5 my-5">
            <div class="row gx-4 gx-lg-5 align-items-center">
               <div class="col-md-6"><img class="card-img-top mb-5 mb-md-0" src="<?php  echo $row['img'];  ?>" alt="..." /></div>
               <div class="col-md-6">
                  <h1 class="display-5 fw-bolder"><?php echo $row['Nume_carte'];?> </h1>
                  <p class="lead"><?php 
                     echo"<p>Autor: {$row['Autor']}</p>";
                     
                     echo"<p>Descriere: {$row['Descriere']}</p>";
                     
                     ?></p>
                  <div class=" row ">
                     <form method="POST"><button type="submit" class="btn btn-primary" name="submit_c" >Sterge carte</button>
                 
                  <?php
                     if(isset($_POST['submit_c'])) {
                     if($categorie=='1'){
                     $result = mysqli_query($con, "DELETE  FROM cartipecarelecitescacum where id = '$image_id'");
                     
                      }
                     if($categorie=='2'){
                       $result = mysqli_query($con, "DELETE  FROM  carticitite where id = '$image_id'");
                       }
                       if($categorie=='3')  {
                         $result = mysqli_query($con, "DELETE  FROM  cartipecarevreausalecitesc where id = '$image_id'");

                        
                     }
                     
                     
                     header("Location: cartileMele.php");
                     }
                      
                     if($categorie=='3')
                     {
                        echo '<button type="submit" class="btn " name="submit_notificaree" ><i class="gg-bell "></i></button>Activeaza notificare';
                     
                        if(isset($_POST['submit_notificaree']))
                        {
                           $quer1 = mysqli_query($con,"UPDATE cartipecarevreausalecitesc SET notificare = '1' WHERE  id = '$image_id'");
                        }
                     }
                     
                        ?>
                        </form>
                         </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Bootstrap core JS-->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
      <!-- Core theme JS-->
      <script src="js/scripts.js"></script>
      <footer class="py-5 bg-dark">
         <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Ana-Ionela-Maria VELESCU</p>
         </div>
      </footer>
   </body>
</html>